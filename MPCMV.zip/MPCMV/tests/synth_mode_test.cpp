#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <dlfcn.h>
#include <vector>
using I=int32_t; using P=intptr_t; struct AEffect;
using Cb=P(*)(AEffect*,I,I,P,void*,float); using Disp=P(*)(AEffect*,I,I,P,void*,float); using Proc=void(*)(AEffect*,float**,float**,I); using Set=void(*)(AEffect*,I,float);
struct AEffect{I magic;Disp dispatcher;Proc process;Set setParameter;float(*getParameter)(AEffect*,I);I numPrograms,numParams,numInputs,numOutputs,flags;P r1,r2;I id,rq,oq;float io;void*object;void*user;I uid,ver;Proc processReplacing,processDoubleReplacing;char future[56];};
struct Ev{I type,byteSize,deltaFrames,flags,noteLength,noteOffset;char data[4];char d1,d2,d3,d4;};
static P host(AEffect*,I op,I,P,void*,float){return op==1?2400:0;}
int main(int argc,char**argv){if(argc!=2)return 2;void*h=dlopen(argv[1],RTLD_NOW);if(!h){puts(dlerror());return 3;}auto entry=(AEffect*(*)(Cb))dlsym(h,"VSTPluginMain");AEffect*f=entry(host);f->dispatcher(f,0,0,0,0,0);f->dispatcher(f,10,0,0,0,44100.f);
 if(f->numParams!=30){printf("FAIL: expected 30 parameters, got %d\n",f->numParams);return 4;} if(f->numPrograms<1){puts("FAIL: no patch programs found");return 7;} char pname[64]{}; f->dispatcher(f,29,0,0,pname,0); if(std::strcmp(pname,"fixture")){printf("FAIL: indexed program name was %s\n",pname);return 8;} f->setParameter(f,29,1.f); if(f->getParameter(f,29)<.99f)return 5;
 Ev e{};e.type=1;e.byteSize=sizeof(e);e.data[0]=(char)0x90;e.data[1]=60;e.data[2]=120;struct{I n;P r;Ev*e[1];}ev{1,0,{&e}};f->dispatcher(f,25,0,0,&ev,0);std::vector<float>l(4096),r(4096);float*out[2]={l.data(),r.data()};f->processReplacing(f,0,out,4096);double energy=0;for(int i=0;i<4096;i++)energy+=fabs(l[i])+fabs(r[i]);
 char name[64]{};f->dispatcher(f,45,0,0,name,0);f->dispatcher(f,1,0,0,0,0);dlclose(h);if(energy<.01){printf("FAIL: synth note 60 silent; energy %.6f\n",energy);return 6;}printf("PASS: synth mode note 60 produced audio (energy %.3f)\n",energy);return 0;}
