#!/usr/bin/env python3
"""Generate a tiny synthetic MVFF kit mirroring the structure of a real MV drum kit
(1 stereo + 1 mono sample). Synthetic audio only; no Roland content."""
import math, struct, sys
def rec(slot, name, pcm_be, stereo):
    frames = len(pcm_be)//(4 if stereo else 2)
    end = frames-1 if stereo else frames-2  # untrimmed end point
    body = struct.pack('>II', 2, slot)+name.encode().ljust(12)+b'\0'*8+struct.pack('>IBBHH', end, 0x27, 60, 0x100 if stereo else 0, 0x2ee0)
    assert len(body)==0x26
    return b'PRM '+struct.pack('>I',0x26)+body+b'WAVE'+struct.pack('>I',len(pcm_be))+pcm_be
def tone(n,f,ch):
    out=bytearray()
    for i in range(n):
        v=int(12000*math.sin(2*math.pi*f*i/44100)*(1-i/n)); 
        for _ in range(ch): out+=struct.pack('>h',v)
    return bytes(out)
smpl=struct.pack('>I',0)+rec(57,'Tone St',tone(4410,220,2),True)+rec(58,'Tone Mono',tone(2200,440,1)+b'\0\0\0\0',False)
kitprm=b'\0\0\0\3\0\0\0\3'+bytes(64)
body=struct.pack('>I',0x75)+b'PAT '+b'FMT '+struct.pack('>I',12)+struct.pack('>3I',0,1,16)+b'PRM '+struct.pack('>I',len(kitprm))+kitprm+b'SMPL'+struct.pack('>I',len(smpl))+smpl
open(sys.argv[1],'wb').write(b'MVFF'+struct.pack('>I',len(body))+body)
