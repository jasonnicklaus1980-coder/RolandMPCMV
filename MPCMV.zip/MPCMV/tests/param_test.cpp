// Behavioural tests for the plugin's named parameters (host-side, x86). Uses the VST2 C ABI only.
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <dlfcn.h>
#include <vector>
#include <string>
using VstInt32=int32_t; using VstIntPtr=intptr_t; struct AEffect;
using Cb=VstIntPtr(*)(AEffect*,VstInt32,VstInt32,VstIntPtr,void*,float);
struct AEffect { VstInt32 magic; Cb dispatcher; void(*process)(AEffect*,float**,float**,VstInt32); void(*setParameter)(AEffect*,VstInt32,float); float(*getParameter)(AEffect*,VstInt32); VstInt32 numPrograms,numParams,numInputs,numOutputs,flags; VstIntPtr r1,r2; VstInt32 id,rq,oq; float io; void*obj;void*user; VstInt32 uid,ver; void(*processReplacing)(AEffect*,float**,float**,VstInt32); void*pd; char fut[56]; };
struct Ev { VstInt32 type,byteSize,deltaFrames,flags,noteLength,noteOffset; char data[4]; char d1,d2,d3,d4; };
static VstIntPtr host(AEffect*,VstInt32 op,VstInt32,VstIntPtr,void*,float){return op==1?2400:0;}
static AEffect*fx; static int fails=0;
static void chk(bool ok,const char*m){std::printf("%s %s\n",ok?"ok  ":"FAIL",m); if(!ok)fails++;}
static void midi(int st,int key,int vel){Ev e{};e.type=1;e.byteSize=sizeof(Ev);e.data[0]=(char)st;e.data[1]=(char)key;e.data[2]=(char)vel; struct{VstInt32 n;VstIntPtr r;Ev*e[1];}b{1,0,{&e}}; fx->dispatcher(fx,25,0,0,&b,0);}
struct R{std::vector<float>l,r;};
static R run(int frames){R o;o.l.resize(frames);o.r.resize(frames);float*p[2]={o.l.data(),o.r.data()};fx->processReplacing(fx,nullptr,p,frames);return o;}
static double en(const std::vector<float>&v,int a,int b){double s=0;for(int i=a;i<b&&i<(int)v.size();i++)s+=std::fabs(v[i]);return s;}
static double rough(const std::vector<float>&v){double d=0,e=1e-9;for(size_t i=1;i<v.size();i++){d+=std::fabs(v[i]-v[i-1]);e+=std::fabs(v[i]);}return d/e;}
static void clean(){fx->dispatcher(fx,1,0,0,0,0);fx->dispatcher(fx,0,0,0,0,0);fx->dispatcher(fx,10,0,0,0,44100.f);}
static void reset(){clean(); // kill voices, restore default parameters
  float d[13]={0.8f,0,.8f,.5f,.5f,.5f,0,.5f,1,.5f,0,1,0}; for(int i=0;i<13;i++)fx->setParameter(fx,i,d[i]); for(int p=0;p<16;p++)fx->setParameter(fx,13+p,.8f);
  for(int p=0;p<16;p++){fx->setParameter(fx,1,p/15.f);for(int i=2;i<=10;i++)fx->setParameter(fx,i,d[i]);} fx->setParameter(fx,1,0); }
int main(int argc,char**argv){ if(argc!=2)return 2; void*h=dlopen(argv[1],RTLD_NOW); if(!h){std::fprintf(stderr,"%s\n",dlerror());return 3;}
  fx=((AEffect*(*)(Cb))dlsym(h,"VSTPluginMain"))(host); fx->dispatcher(fx,0,0,0,0,0); fx->dispatcher(fx,10,0,0,0,44100.f);
  chk(fx->numParams==30,"numParams == 30 (includes Drum/Synth mode)");
  char nm[64]; const char*want[]={"Master","Pad","Level","Pan","Coarse","Fine","Attack","Decay","Sustain","Release","Gate","Cutoff","Reson"};
  bool names=true; for(int i=0;i<13;i++){fx->dispatcher(fx,8,i,0,nm,0); if(std::strcmp(nm,want[i]))names=false;} fx->dispatcher(fx,8,28,0,nm,0); if(std::strcmp(nm,"Pad 16"))names=false; fx->dispatcher(fx,8,29,0,nm,0); if(std::strcmp(nm,"Mode"))names=false; chk(names,"parameter names");
  // baseline: pad 1 (stereo Kick 1)
  reset(); midi(0x90,36,127); R base=run(4096); double e0=en(base.l,0,4096)+en(base.r,0,4096); chk(e0>1,"baseline audio");
  // level
  reset(); fx->setParameter(fx,2,0.f); midi(0x90,36,127); R a=run(4096); chk(en(a.l,0,4096)+en(a.r,0,4096)<1e-6,"pad_level=0 silences pad 1");
  // pad_N_volume aliases selected-pad level
  reset(); fx->setParameter(fx,13,0.f); midi(0x90,36,127); a=run(4096); chk(en(a.l,0,4096)<1e-6,"pad_1_volume=0 silences pad 1");
  reset(); fx->setParameter(fx,1,0.f); fx->setParameter(fx,1,1.f); chk(std::fabs(fx->getParameter(fx,2)-0.8f)<1e-6,"pad_select=1.0 selects pad 16 (own level)");
  // pan hard left
  reset(); fx->setParameter(fx,3,0.f); midi(0x90,36,127); a=run(4096); chk(en(a.r,0,4096)<1e-3*en(a.l,0,4096),"pad_pan=0 -> right channel silent");
  // coarse +12: sample plays twice as fast, so energy after half the length is ~0 (pad 8 SHAKE is short)
  reset(); fx->setParameter(fx,1,7/15.f); midi(0x90,43,127); R n1=run(6000);
  reset(); fx->setParameter(fx,1,7/15.f); fx->setParameter(fx,4,.75f); midi(0x90,43,127); R n2=run(6000);
  auto last=[&](const R&r){double t=en(r.l,0,(int)r.l.size()),c=0;for(int i=0;i<(int)r.l.size();i++){c+=std::fabs(r.l[i]);if(c>=0.99*t)return i;}return (int)r.l.size();};
  int L1=last(n1),L2=last(n2); std::printf("     SHAKE 99%%-energy point: %d frames, +12 st: %d frames\n",L1,L2); chk(L2<L1*0.6&&L2>L1*0.4,"pad_coarse=+12 st halves playback length");
  // attack
  reset(); fx->setParameter(fx,6,.6f); midi(0x90,36,127); a=run(4096); chk(en(a.l,0,512)<0.2*en(base.l,0,512),"pad_attack slows onset");
  // filter
  reset(); fx->setParameter(fx,11,.25f); midi(0x90,40,127); R f=run(8192); reset(); midi(0x90,40,127); R g=run(8192); chk(rough(f.l)<0.6*rough(g.l),"macro_cutoff low smooths signal");
  // gate + release
  reset(); fx->setParameter(fx,10,1.f); fx->setParameter(fx,9,0.f); midi(0x90,36,127); R h1=run(1024); midi(0x80,36,0); R h2=run(2048); chk(en(h1.l,0,1024)>1&&en(h2.l,200,2048)<1e-3,"pad_gate + note-off + release=0 stops voice");
  reset(); midi(0x90,36,127); run(512); midi(0x80,36,0); R h3=run(2048); chk(en(h3.l,0,2048)>1,"one-shot ignores note-off");
  fx->dispatcher(fx,1,0,0,0,0); dlclose(h); std::printf(fails?"FAILED %d\n":"PASS: all parameter tests\n",fails); return fails?1:0; }
