#!/bin/sh
# Runs install.sh / uninstall.sh against a fake device filesystem (MV_TEST_ROOT) with stubbed id/uname/systemctl/pidof.
# Verifies file placement, MPC.settings editing (3 settings shapes), upgrade-in-place, user-sample safety, and uninstall.
set -e
REPO=$(cd "$(dirname "$0")/.." && pwd); SO="${1:-$REPO/build/mpcmv_host_test.so}"
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
sh "$REPO/tools/make_release.sh" "$SO" "$T/out" >/dev/null; REL="$T/out/MPCMV-0.3.2"
mkdir -p "$T/bin"
printf '#!/bin/sh\necho 0\n' > "$T/bin/id"
printf '#!/bin/sh\n[ "$1" = "-m" ] && echo armv7l || /usr/bin/uname "$@"\n' > "$T/bin/uname"
printf '#!/bin/sh\necho "$@" >> "$MV_TEST_LOG"\n' > "$T/bin/systemctl"
printf '#!/bin/sh\nexit 1\n' > "$T/bin/pidof"
chmod +x "$T/bin/"*
SK='mvlib - VST - MPCMV'; fail=0
ok() { echo "ok   $1"; }; bad() { echo "FAIL $1"; fail=1; }
count() { grep -c 'file="/sdcard/vst/mpcmv.so"' "$1" || true; }
valid() { python3 -c 'import sys,xml.etree.ElementTree as E; E.parse(sys.argv[1])' "$1"; }
run() { PATH="$T/bin:$PATH" MV_TEST_ROOT="$FS" MV_TEST_LOG="$T/log" sh "$REL/$1" -y >/dev/null 2>"$T/err"; }

settings() { # $1 = shape
  mkdir -p "$FS/media/az01-internal/Settings/MPC" "$FS/sdcard"; S="$FS/media/az01-internal/Settings/MPC/MPC.settings"
  case "$1" in
   list) cat > "$S" <<'X'
<?xml version="1.0" encoding="UTF-8"?>
<PROPERTIES>
  <VALUE name="SynthContentLocations" val="/sdcard/Synths"/>
  <VALUE name="pluginList-arm">
    <KNOWNPLUGINS>
      <PLUGIN name="Other" format="VST" file="/sdcard/vst/other.so" uid="1"/>
    </KNOWNPLUGINS>
  </VALUE>
</PROPERTIES>
X
   ;; empty) cat > "$S" <<'X'
<?xml version="1.0" encoding="UTF-8"?>
<PROPERTIES>
  <VALUE name="SynthContentLocations" val="/sdcard/Synths"/>
  <VALUE name="pluginList-arm">
    <KNOWNPLUGINS/>
  </VALUE>
</PROPERTIES>
X
   ;; none) cat > "$S" <<'X'
<?xml version="1.0" encoding="UTF-8"?>
<PROPERTIES>
  <VALUE name="SynthContentLocations" val="/sdcard/Synths"/>
</PROPERTIES>
X
   ;; esac; }

for shape in list empty none; do
  FS="$T/fs_$shape"; settings $shape; : > "$T/log"
  run install.sh && ok "$shape: install runs" || { bad "$shape: install failed: $(cat "$T/err")"; continue; }
  [ "$(count "$S")" = 1 ] && valid "$S" && ok "$shape: exactly one entry, valid XML" || bad "$shape: settings entry/XML"
  [ "$shape" != list ] || { grep -q 'other.so' "$S" && ok "list: existing plugin preserved" || bad "list: existing plugin lost"; }
  [ -f "$FS/sdcard/vst/mpcmv.so" ] && [ -f "$FS/sdcard/Synths/$SK/version.xml" ] && [ -f "$FS/sdcard/Synths/$SK/Plugin Skins/TUI.json" ] && [ -f "$FS/sdcard/Synths/$SK/Samples/pad01.wav" ] && ok "$shape: plugin, skin, samples placed" || bad "$shape: files missing"
  ls "$S".bak-mpcmv-* >/dev/null 2>&1 && ok "$shape: settings backup made" || bad "$shape: no backup"
  grep -q 'stop acvs' "$T/log" && grep -q 'start acvs' "$T/log" && ok "$shape: MPC stopped then restarted" || bad "$shape: stop/start missing"
done

FS="$T/fs_list"; S="$FS/media/az01-internal/Settings/MPC/MPC.settings"
echo user > "$FS/sdcard/Synths/$SK/Samples/pad01.wav"; echo mine > "$FS/sdcard/Synths/$SK/Samples/mine.wav"
echo stale > "$FS/sdcard/Synths/$SK/Plugin Skins/old.png"
run install.sh && [ "$(count "$S")" = 1 ] && valid "$S" && ok "upgrade: still one entry" || bad "upgrade: entry count/XML"
[ "$(cat "$FS/sdcard/Synths/$SK/Samples/pad01.wav")" = user ] && [ -f "$FS/sdcard/Synths/$SK/Samples/mine.wav" ] && ok "upgrade: user samples untouched" || bad "upgrade: user samples overwritten"
[ ! -e "$FS/sdcard/Synths/$SK/Plugin Skins/old.png" ] && ok "upgrade: skin replaced cleanly" || bad "upgrade: stale skin file kept"
run uninstall.sh && [ "$(count "$S")" = 0 ] && valid "$S" && grep -q 'other.so' "$S" && ok "uninstall: entry removed, other plugin kept, valid XML" || bad "uninstall: settings"
[ ! -e "$FS/sdcard/vst/mpcmv.so" ] && [ ! -e "$FS/sdcard/Synths/$SK/Plugin Skins" ] && [ -f "$FS/sdcard/Synths/$SK/Samples/mine.wav" ] && ok "uninstall: plugin+skin removed, samples kept" || bad "uninstall: files"

# refusals
FS="$T/fs_list"; printf '#!/bin/sh\n[ "$1" = "-m" ] && echo x86_64\n' > "$T/bin/uname"
if run install.sh; then bad "install should refuse non-ARM"; else grep -q "32-bit ARM" "$T/err" && ok "refuses non-ARM device (with message)" || bad "wrong refusal: $(cat "$T/err")"; fi
printf '#!/bin/sh\n[ "$1" = "-m" ] && echo armv7l\n' > "$T/bin/uname"; echo corrupt >> "$REL/payload/vst/mpcmv.so"
if run install.sh; then bad "install should refuse damaged files"; else grep -q "SHA256SUMS mismatch" "$T/err" && ok "refuses SHA256SUMS mismatch (with message)" || bad "wrong refusal: $(cat "$T/err")"; fi
[ $fail = 0 ] && echo "PASS: installer tests" || { echo "FAILED"; exit 1; }
