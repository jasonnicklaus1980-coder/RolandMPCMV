#include <cstdint>
#include <cstdio>
#include <cstring>
#include <dlfcn.h>
using VstInt32=int32_t; using VstIntPtr=intptr_t; struct AEffect;
using Cb=VstIntPtr(*)(AEffect*,VstInt32,VstInt32,VstIntPtr,void*,float);
struct AEffect { VstInt32 magic; Cb dispatcher; void(*process)(AEffect*,float**,float**,VstInt32); void(*setParameter)(AEffect*,VstInt32,float); float(*getParameter)(AEffect*,VstInt32); VstInt32 numPrograms,numParams,numInputs,numOutputs,flags; VstIntPtr r1,r2; VstInt32 id,rq,oq; float io; void*obj;void*user; VstInt32 uid,ver; void(*processReplacing)(AEffect*,float**,float**,VstInt32); void*pd; char fut[56]; };
static VstIntPtr host(AEffect*,VstInt32 op,VstInt32,VstIntPtr,void*,float){return op==1?2400:0;}
static void check(bool ok,const char*what,int&fails){std::printf("%s %s\n",ok?"PASS":"FAIL",what);if(!ok)fails++;}
int main(int argc,char**argv){if(argc!=2)return 2;void*h=dlopen(argv[1],RTLD_NOW);if(!h){std::puts(dlerror());return 3;} auto create=(AEffect*(*)(Cb))dlsym(h,"VSTPluginMain"); AEffect*f=create(host);if(!f)return 4;f->dispatcher(f,0,0,0,nullptr,0);int fails=0;
  check((f->flags&(1<<5))!=0,"host advertises program chunks",fails);
  f->setParameter(f,0,0.63f);f->setParameter(f,1,0.8f);f->setParameter(f,2,0.37f);f->setParameter(f,3,0.19f);f->setParameter(f,28,0.52f);f->setParameter(f,29,1.f);
  void*chunk=nullptr;VstIntPtr n=f->dispatcher(f,23,0,0,&chunk,0);check(chunk&&n>0,"get chunk returns state bytes",fails);
  // Snapshot bytes independently, then mutate the live plugin state.
  unsigned char copy[4096]; if(n>(VstIntPtr)sizeof(copy))return 5;std::memcpy(copy,chunk,(size_t)n);
  f->setParameter(f,0,0.01f);f->setParameter(f,1,0.f);f->setParameter(f,2,0.f);f->setParameter(f,3,1.f);f->setParameter(f,28,0.f);f->setParameter(f,29,0.f);
  check(f->dispatcher(f,24,0,n,copy,0)==1,"set chunk accepts valid state",fails);
  check(f->getParameter(f,0)>0.62f&&f->getParameter(f,0)<0.64f,"restores master level",fails);
  check(f->getParameter(f,1)>0.79f&&f->getParameter(f,1)<0.81f,"restores selected pad",fails);
  check(f->getParameter(f,2)>0.36f&&f->getParameter(f,2)<0.38f,"restores selected pad parameters",fails);
  check(f->getParameter(f,3)>0.18f&&f->getParameter(f,3)<0.20f,"restores pan",fails);
  check(f->getParameter(f,28)>0.51f&&f->getParameter(f,28)<0.53f,"restores individual pad level",fails);
  check(f->getParameter(f,29)>0.99f,"restores Drum/Synth mode",fails);
  unsigned char bad[8]={0};check(f->dispatcher(f,24,0,8,bad,0)==0,"rejects malformed chunk",fails);
  f->dispatcher(f,1,0,0,nullptr,0);dlclose(h);std::printf(fails?"FAILED %d state checks\n":"PASS all state checks\n",fails);return fails?1:0;}
