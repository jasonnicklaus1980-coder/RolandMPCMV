#!/usr/bin/env python3
import json, subprocess, sys, tempfile, zipfile
from pathlib import Path
with tempfile.TemporaryDirectory() as td:
    root=Path(td); src=root/'src.zip'; out=root/'Samples'/'Patches'
    with zipfile.ZipFile(src,'w') as z:
        z.writestr('PATCHES/DRUMKITS/TestKit.MV0',b'MVFF-test')
        z.writestr('PATCHES/SYNTH/TestSynth.MV0',b'MVFF-synth')
    subprocess.run([sys.executable,'tools/prepare_factory_patches.py',str(src),str(out)],check=True,stdout=subprocess.PIPE,text=True)
    assert (out/'DRUMKITS'/'TestKit.MV0').read_bytes()==b'MVFF-test'
    assert (out/'SYNTH'/'TestSynth.MV0').read_bytes()==b'MVFF-synth'
    report=json.loads((out/'patch-import-report.json').read_text())
    assert report['copied']==2 and report['failed']==0
print('PASS factory patch staging, hierarchy preservation, and report')
