#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <vector>
#include <cmath>
using VstInt32=int32_t; using VstIntPtr=intptr_t; struct AEffect;
using AudioMasterCallback=VstIntPtr(*)(AEffect*,VstInt32,VstInt32,VstIntPtr,void*,float);
using DispatcherProc=VstIntPtr(*)(AEffect*,VstInt32,VstInt32,VstIntPtr,void*,float);
using ProcessProc=void(*)(AEffect*,float**,float**,VstInt32); using SetParameterProc=void(*)(AEffect*,VstInt32,float); using GetParameterProc=float(*)(AEffect*,VstInt32);
struct AEffect { VstInt32 magic; DispatcherProc dispatcher; ProcessProc process; SetParameterProc setParameter; GetParameterProc getParameter; VstInt32 numPrograms,numParams,numInputs,numOutputs,flags; VstIntPtr resvd1,resvd2; VstInt32 initialDelay,realQualities,offQualities; float ioRatio; void*object; void*user; VstInt32 uniqueID,version; ProcessProc processReplacing,processDoubleReplacing; char future[56]; };
struct MidiEvent { VstInt32 type,byteSize,deltaFrames,flags,noteLength,noteOffset; char data[4]; char detune,noteOffVelocity,reserved1,reserved2; }; // matches VstMidiEvent (midiData at offset 24)
static VstIntPtr host(AEffect*,VstInt32 op,VstInt32,VstIntPtr,void*,float){return op==1?2400:0;}
int main(int argc,char**argv){if(argc!=2)return 2;void*h=dlopen(argv[1],RTLD_NOW);if(!h){std::puts(dlerror());return 3;}using Entry=AEffect*(*)(AudioMasterCallback);auto entry=(Entry)dlsym(h,"VSTPluginMain");AEffect*f=entry(host);f->dispatcher(f,0,0,0,nullptr,0);f->dispatcher(f,10,0,0,nullptr,44100.f);
 MidiEvent m{};m.type=1;m.byteSize=sizeof(m);m.deltaFrames=512;m.data[0]=(char)0x90;m.data[1]=36;m.data[2]=127;struct{VstInt32 numEvents;VstIntPtr reserved;MidiEvent*events[1];} ev{1,0,{&m}};f->dispatcher(f,25,0,0,&ev,0);
 const int n=1024;std::vector<float>l(n),r(n);float*out[2]={l.data(),r.data()};f->processReplacing(f,nullptr,out,n);double before=0,after=0;for(int i=0;i<512;i++)before+=std::abs(l[i])+std::abs(r[i]);for(int i=512;i<n;i++)after+=std::abs(l[i])+std::abs(r[i]);f->dispatcher(f,1,0,0,nullptr,0);dlclose(h);if(before>1e-8||after<.01){std::fprintf(stderr,"FAIL MIDI timing: before=%g after=%g\n",before,after);return 4;}std::printf("PASS MIDI deltaFrames timing: silence before frame 512, audio after (%.3f)\n",after);return 0;}
