#!/usr/bin/env python3
"""Render a preview PNG of the generated skin by compositing its own sprites at the positions in TUI.json.
Not an on-device render: knob/fader positions use sample values and text uses an approximation of the MPC label font."""
import json, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
ROOT = Path(__file__).resolve().parents[1]; D = ROOT / 'payload/Synths/mvlib - VST - MPCMV/Plugin Skins'
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'build/mv_skin_preview.png'
NAMES = {0: 'Master', 1: 'Pad', 2: 'Level', 3: 'Pan', 4: 'Coarse', 5: 'Fine', 6: 'Attack', 7: 'Decay', 8: 'Sustain', 9: 'Release', 10: 'Gate', 11: 'Cutoff', 12: 'Reson', 29: 'Mode'}
VALS = {0: ('0.0 dB', .8), 1: ('5', 4 / 15), 2: ('0.0 dB', .8), 3: ('C', .5), 4: ('0 st', .5), 5: ('0 ct', .5), 6: ('0.002 s', 0.0), 7: ('0.250 s', .5),
        8: ('127', 1.0), 9: ('0.250 s', .5), 10: ('Gate', 1.0), 11: ('20000 Hz', 1.0), 12: ('0%', 0.0), 29: ('Drums', 0.0)}
def font(sz):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 'DejaVuSans-Bold.ttf'):
        try: return ImageFont.truetype(p, max(6, int(sz)))
        except OSError: pass
    return ImageFont.load_default()
def col(h): h = h[-8:]; return tuple(int(h[i:i + 2], 16) for i in (2, 4, 6)) + (int(h[0:2], 16),)
tui = json.load(open(D / 'TUI.json'))['pageData']; defs = {d['key']: d['value'] for d in tui['componentDefinitions']['localComponentDefinitions']}
def pidx(c): return int(c['handle remapping']['map'][0]['value'].split()[1])
def render(tab):
    comps = defs[tab['componentName']]['componentsData']; cv = None
    for c in comps:
        cd = c['componentData']
        if cd['type'] == 'Image': cv = Image.open(D / cd['data']['image']).convert('RGBA'); continue
        X, Y = map(int, c['bounds']['bounds'].split()[:2]); idx = pidx(c); txt, v = VALS.get(idx, ('-6.0 dB', .6))
        if idx >= 13 and idx < 29: txt, v = '-1.9 dB', 0.55 + (idx - 13) % 5 * 0.08
        nm = NAMES.get(idx, 'Pad %d' % (idx - 12)); d = ImageDraw.Draw(cv)
        for s in defs[cd['name'] if cd['name'] in defs else c['componentData']['type']]['componentsData']:
            sd = s['componentData']; x, y, w, h = map(int, s['bounds']['bounds'].split()); x += X; y += Y
            if sd['type'] == 'Knob':
                fs = Image.open(D / sd['data']['filmStrip']).convert('RGBA'); n = sd['data']['numFrames']; f = int(v * (n - 1))
                cv.alpha_composite(fs.crop((0, f * h, w, f * h + h)), (x, y))
            elif sd['type'] == 'Button':
                cv.alpha_composite(Image.open(D / (sd['data']['onImage'] if v >= .5 else sd['data']['offImage'])).convert('RGBA'), (x, y))
            elif sd['type'] == 'Label':
                t = nm if sd['data']['type'] == 'Name' else txt
                if sd['data']['textStyle']['case'] == 'Upper Case': t = t.upper()
                d.text((x + w / 2, y + h / 2), t, font=font(sd['data']['textStyle']['font']['height'] * .8), fill=col(sd['data']['textStyle']['colour']), anchor='mm')
    return cv
imgs = [render(t) for t in tui['tabs']]
OUT.parent.mkdir(parents=True, exist_ok=True)
sheet = Image.new('RGB', (1280, 628 * len(imgs) + 10 * (len(imgs) - 1)), (0, 0, 0))
for i, im in enumerate(imgs): sheet.paste(im.convert('RGB'), (0, i * 638))
sheet.save(OUT); print('wrote', OUT)
