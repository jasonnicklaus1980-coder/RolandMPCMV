#!/usr/bin/env python3
"""Safely stage Roland MV factory .MV0 patches for the MPC plugin.

Usage: python3 tools/prepare_factory_patches.py factory.zip Samples/Patches

The tool copies the .MV0 patch files only; it does not alter patch bytes or
claim that the proprietary key/velocity zone and synthesis PRM blocks are decoded.
Bad ZIP members are reported and skipped rather than silently treated as valid.
"""
import argparse, json, zipfile
from pathlib import Path, PurePosixPath

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('archive',type=Path)
    ap.add_argument('destination',type=Path)
    ap.add_argument('--report',type=Path,default=None)
    a=ap.parse_args()
    if not zipfile.is_zipfile(a.archive): ap.error('source is not a valid ZIP archive')
    dest=a.destination.resolve(); dest.mkdir(parents=True,exist_ok=True)
    copied=[]; errors=[]; seen=0
    with zipfile.ZipFile(a.archive) as z:
        for info in z.infolist():
            if info.is_dir() or not info.filename.lower().endswith('.mv0'): continue
            rel=PurePosixPath(info.filename)
            parts=list(rel.parts)
            # Strip the common PATCHES root so the plugin sees Samples/Patches/<category>/...
            if parts and parts[0].upper()=='PATCHES': parts=parts[1:]
            if not parts or any(p in ('..','.') for p in parts) or rel.is_absolute():
                errors.append({'file':info.filename,'error':'unsafe archive path'}); continue
            target=dest.joinpath(*parts).resolve()
            if dest not in target.parents:
                errors.append({'file':info.filename,'error':'path escapes destination'}); continue
            seen+=1
            try:
                data=z.read(info) # forces CRC validation
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(data)
                copied.append({'file':info.filename,'output':str(target.relative_to(dest)),'bytes':len(data)})
            except Exception as e:
                errors.append({'file':info.filename,'error':str(e)})
    report={'format':'mvlib-patch-stage-v1','archive':a.archive.name,'destination':str(dest),
            'mv0_files_seen':seen,'copied':len(copied),'failed':len(errors),'files':copied,'errors':errors,
            'notes':['Patch bytes are preserved unchanged.','This stages factory patch files for playback; it does not decode proprietary patch zones, synthesis parameters, or effects.']}
    rp=a.report or (dest/'patch-import-report.json')
    rp.parent.mkdir(parents=True,exist_ok=True); rp.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'seen':seen,'copied':len(copied),'failed':len(errors),'report':str(rp)},indent=2))
    return 0 if copied else 1
if __name__=='__main__': raise SystemExit(main())
