#!/usr/bin/env python3
"""Generate the MV MPC plugin skin: TUI.json, Q-Links.json (+ '8by1' copy) and PNG sprites.

Schema learned from the JV-880 MPC plugin skin (TUI.json / Q-Links.json):
  * canvas 1280x628 per tab; controls are component definitions placed with 'bounds' "x y w h"
  * a control binds to a VST2 parameter INDEX via "handle remapping": Data -> "Parameter N"
  * Q-Links.json maps Q-Link 1..16 -> parameter index (-1 = unused), per tab, plus Program Mode
  * knobs/sliders are FilmStrip PNGs (127 frames). ASSUMPTION: frames are stacked vertically.
"""
import json, math, shutil, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'payload/Synths/mvlib - VST - MPCMV/Plugin Skins'
FRAMES = 127
# VST2 parameter indices (see docs/PARAMETERS.md / src/mpcmv_vst2.cpp)
MASTER, PAD, LEVEL, PAN, COARSE, FINE, ATTACK, DECAY, SUSTAIN, RELEASE, GATE, CUTOFF, RESON, PADVOL0 = range(14)
NPARAMS = 30

# ---------- JSON building blocks (shapes copied from the JV-880 skin) ----------
def action(on, handler, handle='', extra=''):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": handle, "additionalData": extra,
            "handle remapping": {"version": 1, "map": []}}
KNOB_ACTIONS = [action('Mouse Down', 'Q-Link', 'Data'), action('Double Click', 'Show Overlay', '', 'knob overlay'),
                action('Enter Pressed', 'Show Overlay', '', 'knob overlay')]
TOGGLE_ACTIONS = [action('Mouse Down', 'Q-Link', 'Data'), action('Enter Pressed', 'Toggle Switch', 'Data')]
def bounds(b, hw='No', inv='Show', vis='Always'):
    return {"version": 2, "acceptsHWFocus": hw, "showWhenDataModelInvalid": inv, "whenVisible": vis,
            "boundsType": "Absolute", "bounds": b, "additionalInvalidatingHandles": []}
def item(name, typ, data, b, remap=None, **kw):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": typ, "data": data},
            "handle remapping": {"version": 1, "map": remap or []}, "bounds": bounds(b, **kw)}
def focus(b):
    return item('Focus', 'Focus', {"version": 1, "backgroundColour": "00000000", "outlineColour": "ff238cff",
                "backgroundInset": 2.0, "outlineThickness": 2.0}, b, vis='WhenFocussed')
def label(name, kind, b, height, colour, case='Original'):
    return item(name, 'Label', {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": "Titillium Web",
                "style": "SemiBold", "height": height}, "colour": colour, "justification": "horizontallyCentred verticallyCentred",
                "case": case}, "type": kind, "handleName": "Data"}, b)
def filmstrip(png, b):
    return item('Knob', 'Knob', {"version": 5, "knobType": "FilmStrip", "filmStrip": png, "numFrames": FRAMES, "invert": False,
                "dragOrientation": "Vertical", "handleName": "Data"}, b)
def button(on, off, b):
    return item('Button', 'Button', {"version": 2, "onImage": on, "offImage": off, "buttonId": 1, "numButtonsInGroup": 1,
                "handleName": "Data", "gestureBehaviour": "Instant"}, b)
def bg_image(png):
    return item('Background', 'Image', {"version": 2, "imageType": "Regular", "colour": "0", "image": png}, '0 0 1280 628')
def definition(key, actions, comps, colour='0'):
    bgd = {"version": 1, "colour": colour, "image": ""}
    return {"key": key, "value": {"version": 4, "actions": actions,
            "backgroundData": {"version": 1, "focussed": dict(bgd), "unfocussed": dict(bgd)}, "ignoreMousePresses": False,
            "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True, "componentsData": comps}}
def inst(name, typ, idx, x, y, w, h):
    return item(name, typ, {"version": 1, "handleName": "Data"}, f'{x} {y} {w} {h}',
                remap=[{"key": "Data", "value": f"Parameter {idx}"}], hw='Yes', inv='Hide')

def inst(name, typ, idx, x, y, w, h, hw='Yes'):
    return item(name, typ, {"version": 1, "handleName": "Data"}, f'{x} {y} {w} {h}',
                remap=[{"key": "Data", "value": f"Parameter {idx}"}], hw=hw, inv='Hide')

# ---------- Layout (1280x628), modelled on the MV-8000 front panel ----------
DARK, LIGHT = 'ff11161c', 'fff1f5f8'            # label colours on silver / on dark
LCD_NAME, LCD_VAL = 'ff9fc9ed', 'fff1f5f8'
SLIDER_NAME = 'ffd8dde2'
KP = (72, 112)                                   # pad-editor knob instance (name above, knob, value box below)
PE_X, PE_Y1, PE_Y2 = 318, 336, 470               # pad editor rows
QE_X, QE_Y = 137, 76                             # quick edit stack
SL_X, SL_Y1, SL_Y2 = 914, 340, 460               # pad-volume faders (2 rows x 8)

def build_json():
    ro = lambda extra: extra  # readability helper
    defs = [
        # pad-editor / master knob: name above, 58px knob, value in a dark box below
        definition('mvKnob', KNOB_ACTIONS, [focus('0 0 72 112'), label('Name', 'Name', '0 0 72 18', 14.0, DARK),
            filmstrip('mv_knob.png', '7 20 58 58'), label('Value', 'Value', '4 84 64 20', 13.0, LIGHT)]),
        # quick-edit knob: small knob with the name beside it
        definition('mvQuick', KNOB_ACTIONS, [focus('0 0 100 52'), filmstrip('mv_knob_s.png', '6 6 40 40'),
            label('Name', 'Name', '48 15 52 20', 13.0, DARK, 'Upper Case')]),
        # pad-volume fader (main screen)
        definition('mvFaderS', KNOB_ACTIONS, [focus('0 0 44 100'), label('Name', 'Name', '0 0 44 16', 11.0, SLIDER_NAME),
            filmstrip('mv_slider_s.png', '8 18 28 80')]),
        # large fader (Mixer tab)
        definition('mvSlider', KNOB_ACTIONS, [focus('0 0 64 155'), filmstrip('mv_slider.png', '15 0 34 99'),
            label('Name', 'Name', '0 101 64 20', 15.0, SLIDER_NAME), label('Value', 'Value', '0 123 64 26', 17.0, LCD_NAME)]),
        # segmented switches (two-state parameters)
        definition('mvSegMode', TOGGLE_ACTIONS, [focus('0 0 104 76'), button('mv_seg_mode_on.png', 'mv_seg_mode_off.png', '0 0 104 76')]),
        definition('mvSegGate', TOGGLE_ACTIONS, [focus('0 0 150 40'), button('mv_seg_gate_on.png', 'mv_seg_gate_off.png', '0 0 150 40')]),
        # LCD read-outs (display only, bound to the same parameters as the knobs)
        definition('mvReadBig', [], [label('Name', 'Name', '0 0 130 20', 14.0, LCD_NAME), label('Value', 'Value', '0 24 130 84', 78.0, LCD_VAL)]),
        definition('mvRead', [], [label('Name', 'Name', '0 0 140 18', 14.0, LCD_NAME), label('Value', 'Value', '0 20 140 40', 30.0, LCD_VAL)]),
    ]
    # --- Pad tab (single MV-8000-style screen)
    comps = [bg_image('mv_bg_0.png')]
    comps.append(inst('MODE', 'mvSegMode', 29, 20, 82, 104, 76))
    comps.append(inst('PAD', 'mvKnob', PAD, 34, 182, *KP))
    for i, (nm, idx) in enumerate([('CUTOFF', CUTOFF), ('RESON', RESON), ('ATTACK', ATTACK), ('RELEASE', RELEASE)]):
        comps.append(inst(nm, 'mvQuick', idx, QE_X, QE_Y + i * 56, 100, 52))
    # LCD
    comps.append(inst('LCD PAD', 'mvReadBig', PAD, 270, 110, 130, 110, hw='No'))
    for (nm, idx, x, y) in [('LCD MODE', 29, 420, 100), ('LCD GATE', GATE, 566, 100), ('LCD MASTER', MASTER, 712, 100),
                            ('LCD CUTOFF', CUTOFF, 420, 190), ('LCD RESON', RESON, 566, 190), ('LCD LEVEL', LEVEL, 712, 190)]:
        comps.append(inst(nm, 'mvRead', idx, x, y, 140, 64, hw='No'))
    comps.append(inst('MASTER', 'mvKnob', MASTER, 1090, 170, *KP))
    for i, (nm, idx) in enumerate([('LEVEL', LEVEL), ('PAN', PAN), ('COARSE', COARSE), ('FINE', FINE),
                                   ('ATTACK', ATTACK), ('DECAY', DECAY), ('SUSTAIN', SUSTAIN), ('RELEASE', RELEASE)]):
        comps.append(inst('PE ' + nm, 'mvKnob', idx, PE_X + i * 72, PE_Y1, *KP))
    comps.append(inst('PE CUTOFF', 'mvKnob', CUTOFF, PE_X, PE_Y2, *KP))
    comps.append(inst('PE RESON', 'mvKnob', RESON, PE_X + 72, PE_Y2, *KP))
    comps.append(inst('GATE', 'mvSegGate', GATE, 560, 492, 150, 40))
    for i in range(16):
        comps.append(inst(f'PAD {i+1}', 'mvFaderS', PADVOL0 + i, SL_X + (i % 8) * 44, SL_Y1 if i < 8 else SL_Y2, 44, 100))
    defs.append(definition('PAD|Pad', [], comps, 'ffaeb4b8'))
    # --- Mixer tab
    comps = [bg_image('mv_bg_1.png')]
    for i in range(16):
        comps.append(inst(f'PAD {i+1}', 'mvSlider', PADVOL0 + i, 85 + i * 70, 200, 64, 155))
    defs.append(definition('MIXER|Mixer', [], comps, 'ffaeb4b8'))
    tabs = [{"version": 3, "tabName": n, "fnKeyIndex": i, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
             "componentName": f"{n.upper()}|{n}", "initialSize": "0 0 1280 628", "scale": 1.0} for i, n in enumerate(['Pad', 'Mixer'])]
    tui = {"pageData": {"version": 1, "componentDefinitions": {"version": 2, "importFiles": [
        "/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json", "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
        "localComponentDefinitions": defs}, "info": {"version": 1, "type": "CompleteDescription"}, "tabs": tabs}}
    pad_q = [CUTOFF, RESON, ATTACK, RELEASE, LEVEL, PAN, COARSE, FINE, DECAY, SUSTAIN, PAD, GATE, MASTER, 29, -1, -1]
    mix_q = [PADVOL0 + i for i in range(16)]
    ql = lambda v: {f"Q-Link {i+1}": x for i, x in enumerate(v)}
    qjson = {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
             "Screen Mode Q-Links": {"version": 4, "map": [
                 {"Tab": 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": ql(pad_q)},
                 {"Tab": 2, "SubTab": 1, "Bank Direction": "Column", "Q-Links": ql(mix_q)}]},
             "Program Mode Q-Links": ql(pad_q)}
    return tui, qjson

# ---------- Artwork ----------
SS = 4   # sprite supersampling
K = 2    # background supersampling
def font(sz, bold=True):
    name = 'DejaVuSans%s.ttf' % ('-Bold' if bold else '')
    for d in ('/usr/share/fonts/truetype/dejavu/', '/usr/share/fonts/dejavu/', '/Library/Fonts/', ''):
        try: return ImageFont.truetype(d + name, int(sz))
        except OSError: pass
    try: return ImageFont.load_default(size=int(sz))
    except TypeError: return ImageFont.load_default()

def knob_strip(path, size, ticks=True):
    W = H = size; strip = Image.new('RGBA', (W, H * FRAMES), (0, 0, 0, 0)); k = size / 58.0
    for f in range(FRAMES):
        v = f / (FRAMES - 1); im = Image.new('RGBA', (W * SS, H * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = W * SS / 2
        if ticks:
            for t in range(11):
                a = math.radians(-135 + 270 * t / 10); r0, r1 = 25 * k * SS, 28.5 * k * SS if t in (0, 5, 10) else 27.5 * k * SS
                d.line([c + r0 * math.sin(a), c - r0 * math.cos(a), c + r1 * math.sin(a), c - r1 * math.cos(a)], fill=(52, 58, 64, 255), width=max(1, int(1.6 * k * SS)))
        r = 21 * k * SS
        d.ellipse([c - r - SS, c - r - SS + 2 * SS, c + r + SS, c + r + SS + 2 * SS], fill=(0, 0, 0, 70))     # drop shadow
        for i in range(12):                                                                                    # radial body gradient
            rr = r * (1 - i / 14.0); g = 18 + i * 3
            d.ellipse([c - rr, c - rr, c + rr, c + rr], fill=(g, g, g + 2, 255))
        d.ellipse([c - r, c - r, c + r, c + r], outline=(92, 98, 104, 255), width=max(1, int(1.2 * k * SS)))
        d.ellipse([c - r * .62, c - r * .8 - 0, c + r * .62, c - r * .1], fill=(255, 255, 255, 18))            # top sheen
        a = math.radians(-135 + 270 * v)
        d.line([c + 6 * k * SS * math.sin(a), c - 6 * k * SS * math.cos(a), c + 18 * k * SS * math.sin(a), c - 18 * k * SS * math.cos(a)],
               fill=(246, 248, 250, 255), width=max(2, int(3 * k * SS)))
        strip.paste(im.resize((W, H), Image.LANCZOS), (0, f * H))
    strip.save(path)

def slider_strip(path, W, H, cap_w, cap_h, top, bot):
    strip = Image.new('RGBA', (W, H * FRAMES), (0, 0, 0, 0))
    for f in range(FRAMES):
        v = f / (FRAMES - 1); im = Image.new('RGBA', (W * SS, H * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        y = (bot - (bot - top) * v) * SS; cx = W * SS / 2
        d.rounded_rectangle([cx - 3 * SS, (top - 3) * SS, cx + 3 * SS, (bot + 3) * SS], 2 * SS, fill=(4, 5, 6, 255), outline=(60, 66, 72, 255))
        hw, hh = cap_w * SS / 2, cap_h * SS / 2
        d.rounded_rectangle([cx - hw, y - hh, cx + hw, y + hh], 3 * SS, fill=(178, 184, 188, 255), outline=(8, 8, 8, 255), width=SS)
        d.rectangle([cx - hw + SS, y - hh + SS, cx + hw - SS, y - hh + 3 * SS], fill=(226, 230, 233, 255))      # top highlight
        for ry in (-hh * .45, -hh * .05, hh * .35):                                                           # grip ridges
            d.line([cx - hw + 3 * SS, y + ry, cx + hw - 3 * SS, y + ry], fill=(96, 102, 108, 255), width=SS)
        d.line([cx - hw + 2 * SS, y + hh * .75, cx + hw - 2 * SS, y + hh * .75], fill=(30, 30, 30, 255), width=SS)
        strip.paste(im.resize((W, H), Image.LANCZOS), (0, f * H))
    strip.save(path)

def seg_switch(path, size, labels, lit, vertical):
    W, H = size; im = Image.new('RGBA', (W * SS, H * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, W * SS - 1, H * SS - 1], 5 * SS, fill=(14, 17, 21, 255), outline=(70, 77, 84, 255), width=SS)
    n = len(labels)
    for i, t in enumerate(labels):
        if vertical: box = [3 * SS, (3 + i * (H - 6) / n) * SS, (W - 3) * SS, (3 + (i + 1) * (H - 6) / n - 1) * SS]
        else: box = [(3 + i * (W - 6) / n) * SS, 3 * SS, (3 + (i + 1) * (W - 6) / n - 1) * SS, (H - 3) * SS]
        on = (i == lit)
        d.rounded_rectangle(box, 3 * SS, fill=(35, 140, 255, 255) if on else (30, 35, 41, 255), outline=(90, 175, 255, 255) if on else (48, 54, 60, 255))
        d.text(((box[0] + box[2]) / 2, (box[1] + box[3]) / 2), t, font=font(12 * SS * (0.92 if len(t) > 6 else 1)), anchor='mm',
               fill=(255, 255, 255, 255) if on else (140, 148, 156, 255))
    im.resize((W, H), Image.LANCZOS).save(path)

def metal(w, h, seed=7):
    import numpy as np
    rng = np.random.RandomState(seed)
    y = np.linspace(0, 1, h)[:, None]; base = 186 - 26 * y
    streak = rng.normal(0, 3.2, (h, 1)) + rng.normal(0, 1.2, (h, w)) * 0.6
    a = np.clip(base + streak, 0, 255)
    rgb = np.stack([a - 2, a + 3, a + 6], axis=2).clip(0, 255).astype('uint8')
    return Image.fromarray(rgb, 'RGB').convert('RGBA')

class Art:
    def __init__(self, base): self.im = base.convert('RGB'); self.d = ImageDraw.Draw(self.im, 'RGBA')   # RGB base so translucent fills blend
    def rr(self, box, r=6, fill=None, outline=None, w=1):
        self.d.rounded_rectangle([c * K for c in box], r * K, fill=fill, outline=outline, width=max(1, int(w * K)))
    def tx(self, xy, s, sz, fill, anchor='la', bold=True): self.d.text((xy[0] * K, xy[1] * K), s, font=font(sz * K, bold), fill=fill, anchor=anchor)
    def ln(self, pts, fill, w=1): self.d.line([c * K for p in pts for c in p], fill=fill, width=max(1, int(w * K)))
    def recess(self, box, title=None, tc=(17, 22, 28, 255)):
        x0, y0, x1, y1 = box; self.rr(box, 8, fill=(0, 0, 0, 34), outline=(84, 90, 96, 255), w=1.5)
        self.ln([(x0 + 3, y1 - 1), (x1 - 3, y1 - 1)], (235, 238, 240, 150), 1)
        if title: self.tx((x0 + 10, y0 + 5), title, 11, tc)
    def dark(self, box, title=None):
        x0, y0, x1, y1 = box; self.rr(box, 8, fill=(16, 20, 24, 255), outline=(81, 89, 96, 255), w=1.5)
        if title: self.tx((x0 + 10, y0 + 6), title, 11, (216, 221, 226, 255))
    def header(self, active):
        self.d.rectangle([0, 0, 1280 * K, 44 * K], fill=(20, 22, 25, 255)); self.d.rectangle([0, 44 * K, 1280 * K, 47 * K], fill=(8, 9, 10, 255))
        self.tx((14, 22), 'MPCMV', 28, (241, 245, 248, 255), 'lm'); self.tx((140, 14), 'MV-8000 STYLE', 11, (200, 40, 48, 255)); self.tx((140, 29), 'SAMPLE INSTRUMENT', 11, (130, 138, 146, 255))
        x = 794
        for t in ['BROWSE', 'PAD', 'MIXER', 'EFFECTS', 'SYSTEM']:
            on = (t == active); live = t in ('PAD', 'MIXER')
            self.rr((x, 6, x + 90, 38), 4, fill=(18, 50, 95, 255) if on else (30, 33, 37, 255), outline=(35, 140, 255, 255) if on else (58, 62, 68, 255), w=1.5 if on else 1)
            self.tx((x + 45, 22), t, 12, (241, 245, 248, 255) if on else ((200, 205, 210, 255) if live else (88, 94, 100, 255)), 'mm'); x += 96
    def footer(self, text):
        self.d.rectangle([0, 602 * K, 1280 * K, 628 * K], fill=(20, 22, 25, 255)); self.d.rectangle([0, 602 * K, 1280 * K, 604 * K], fill=(8, 9, 10, 255))
        self.tx((16, 616), text, 12, (150, 158, 166, 255), 'lm', bold=False)
    def out(self, path): self.im.convert('RGB').resize((1280, 628), Image.LANCZOS).save(path, optimize=True)

def backgrounds(out):
    chassis = metal(1280 * K, 628 * K)
    # ---------------- Pad tab ----------------
    a = Art(chassis.copy()); a.header('PAD')
    a.recess((12, 54, 128, 170), 'MODE'); a.recess((12, 178, 128, 298), None)
    a.recess((136, 54, 238, 298), 'QUICK EDIT')
    for i in range(4): pass
    # LCD bezel + screen
    a.rr((246, 54, 900, 298), 12, fill=(12, 14, 17, 255), outline=(60, 64, 70, 255), w=2)
    a.rr((256, 62, 890, 290), 4, fill=(20, 42, 66, 255), outline=(8, 20, 34, 255), w=2)
    a.d.rectangle([258 * K, 64 * K, 888 * K, 86 * K], fill=(159, 201, 237, 255)); a.tx((268, 75), 'PAD PARAMETERS', 12, (17, 24, 32, 255), 'lm')
    a.tx((884, 75), 'selected pad / global', 10, (40, 70, 100, 255), 'rm', False)
    a.rr((262, 94, 410, 282), 3, fill=(14, 32, 52, 255), outline=(46, 84, 122, 255))
    for (x, y) in [(420, 96), (566, 96), (712, 96), (420, 186), (566, 186), (712, 186)]:
        a.rr((x - 4, y, x + 144, y + 76), 3, fill=(14, 32, 52, 255), outline=(46, 84, 122, 255))
    a.tx((572, 274), 'MPC pads 1-16 trigger MV pads 1-16 (MIDI notes 36-51) in Drums mode', 10, (120, 160, 200, 255), 'mm', False)
    # master section
    a.tx((924, 62), 'MV-8000 STYLE', 14, (200, 40, 48, 255)); a.tx((924, 82), 'MPCMV', 56, (17, 22, 28, 255)); a.tx((926, 140), 'SAMPLE INSTRUMENT', 14, (40, 46, 52, 255))
    a.recess((1040, 166, 1272, 298), None)
    # pad grid
    a.rr((12, 306, 300, 598), 8, fill=(14, 16, 19, 255), outline=(60, 64, 70, 255), w=2)
    for r in range(4):
        for c in range(4):
            n = (3 - r) * 4 + c + 1; x = 24 + c * 68; y = 318 + r * 68
            a.rr((x, y, x + 60, y + 60), 5, fill=(104, 108, 112, 255), outline=(30, 32, 34, 255), w=1.5)
            a.d.rectangle([(x + 3) * K, (y + 3) * K, (x + 57) * K, (y + 22) * K], fill=(255, 255, 255, 22))
            a.tx((x + 6, y + 6), str(n), 13, (22, 24, 26, 255))
    # pad editor
    a.recess((308, 306, 900, 598), 'PAD PARAMETERS')
    a.tx((318, 456), 'FILTER', 10, (60, 68, 76, 255), 'lm'); a.tx((560, 480), 'ENVELOPE MODE', 10, (60, 68, 76, 255), 'lm')
    a.ln([(312, 454), (896, 454)], (84, 90, 96, 160), 1)
    for r_y in (PE_Y1, PE_Y2):
        for i in range(8 if r_y == PE_Y1 else 2):
            x = PE_X + i * 72; a.rr((x + 6, r_y + 84, x + 66, r_y + 104), 3, fill=(26, 30, 34, 255), outline=(70, 76, 82, 255))
    # master value box and pad select box
    a.rr((1090 + 6, 170 + 84, 1090 + 66, 170 + 104), 3, fill=(26, 30, 34, 255), outline=(70, 76, 82, 255))
    a.rr((34 + 6, 182 + 84, 34 + 66, 182 + 104), 3, fill=(26, 30, 34, 255), outline=(70, 76, 82, 255))
    # pad volume
    a.dark((906, 306, 1272, 598), 'PAD VOLUME')
    for r_y in (SL_Y1, SL_Y2):
        a.ln([(912, r_y - 4), (1266, r_y - 4)], (50, 56, 62, 255), 1)
    a.footer('Q-Link 1-4: Cutoff, Reson, Attack, Release   5-8: Level, Pan, Coarse, Fine   9-12: Decay, Sustain, Pad, Gate   13: Master   14: Mode')
    a.out(out / 'mv_bg_0.png')
    # ---------------- Mixer tab ----------------
    a = Art(chassis.copy()); a.header('MIXER')
    a.dark((60, 130, 1220, 400), 'PAD VOLUME  -  Q-Links 1-16 control pads 1-16')
    a.footer('Mixer: one fader per pad. Drums mode: pad n = MIDI note 35+n.')
    a.out(out / 'mv_bg_1.png')

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for old in ('mv_pill_on.png', 'mv_pill_off.png'):
        if (OUT / old).exists(): (OUT / old).unlink()
    tui, q = build_json()
    (OUT / 'TUI.json').write_text(json.dumps(tui, indent=4), encoding='utf-8')
    (OUT / 'Q-Links.json').write_text(json.dumps(q, indent=4), encoding='utf-8')
    shutil.copyfile(OUT / 'Q-Links.json', OUT / 'Q-Links - 8by1.json')
    knob_strip(OUT / 'mv_knob.png', 58); knob_strip(OUT / 'mv_knob_s.png', 40, ticks=False)
    slider_strip(OUT / 'mv_slider.png', 34, 99, 28, 16, 14, 85); slider_strip(OUT / 'mv_slider_s.png', 28, 80, 24, 13, 10, 70)
    seg_switch(OUT / 'mv_seg_mode_off.png', (104, 76), ['DRUM KIT', 'SYNTH'], 0, True)
    seg_switch(OUT / 'mv_seg_mode_on.png', (104, 76), ['DRUM KIT', 'SYNTH'], 1, True)
    seg_switch(OUT / 'mv_seg_gate_off.png', (150, 40), ['ONE-SHOT', 'GATE'], 0, False)
    seg_switch(OUT / 'mv_seg_gate_on.png', (150, 40), ['ONE-SHOT', 'GATE'], 1, False)
    backgrounds(OUT)
    if OUT.name == 'Plugin Skins':   # version.xml sits next to 'Plugin Skins' (format from the JV-880 package)
        (OUT.parent / 'version.xml').write_text("<?xml version='1.0' encoding='utf-8'?>\n<plugincontent version=\"1.0\">\n\t<identifier>mvlib.vst.mpcmv</identifier>\n\t<version>0.3.2.0</version>\n</plugincontent>\n", encoding='utf-8')
    print('wrote', OUT)
if __name__ == '__main__':
    main()
