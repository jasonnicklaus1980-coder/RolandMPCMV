#!/bin/sh
# Assemble an installable release folder (+ zip) in the JV-880 package layout, with SHA256SUMS.
#   tools/make_release.sh path/to/mpcmv.so out_dir
set -e
SO_SRC="$1"; OUT="$2"; [ -f "$SO_SRC" ] && [ -n "$OUT" ] || { echo "usage: $0 mpcmv.so out_dir" >&2; exit 2; }
ROOT=$(cd "$(dirname "$0")/.." && pwd)
SKIN='mvlib - VST - MPCMV'; VER=0.3.2; REL="$OUT/MPCMV-$VER"
rm -rf "$REL"; mkdir -p "$REL/payload/vst" "$REL/payload/Synths/$SKIN/Samples"
cp "$ROOT/INSTALL.md" "$ROOT/install.sh" "$ROOT/uninstall.sh" "$ROOT/plugin.xml" "$ROOT/plugin_list.awk" "$REL/"
cp "$SO_SRC" "$REL/payload/vst/mpcmv.so"
cp "$ROOT/payload/Synths/$SKIN/version.xml" "$REL/payload/Synths/$SKIN/"
cp -r "$ROOT/payload/Synths/$SKIN/Plugin Skins" "$REL/payload/Synths/$SKIN/"
cp "$ROOT"/Samples/pad*.wav "$REL/payload/Synths/$SKIN/Samples/"
# Include factory patches only when the user has staged them; preserve category folders.
if [ -d "$ROOT/Samples/Patches" ]; then cp -r "$ROOT/Samples/Patches" "$REL/payload/Synths/$SKIN/Samples/"; fi
if [ -d "$ROOT/Samples/Dirt-Grime" ]; then cp -r "$ROOT/Samples/Dirt-Grime" "$REL/payload/Synths/$SKIN/Samples/"; fi
( cd "$REL" && find . -type f ! -name SHA256SUMS | sed 's|^\./||' | LC_ALL=C sort | while IFS= read -r f; do sha256sum "$f"; done > SHA256SUMS )
( cd "$OUT" && rm -f "MPCMV-$VER.zip" && zip -qr "MPCMV-$VER.zip" "MPCMV-$VER" )
echo "release: $REL  (+ $OUT/MPCMV-$VER.zip)"
