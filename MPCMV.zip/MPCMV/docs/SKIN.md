# MPC skin (experimental, generated)

`python3 tools/build_skin.py` writes `payload/Synths/mvlib - VST - MPCMV/Plugin Skins/`: `TUI.json`, `Q-Links.json`, `Q-Links - 8by1.json` (byte-identical copy, as in the JV-880 package) and PNG sprites. `make test-skin` regenerates and validates it.

## Schema (read from the JV-880 `TUI.json` / `Q-Links.json`)
- 1280x628 canvas per tab; `tabs[]` -> `componentName` ("PAD|Pad") -> a local component definition holding `componentsData` (background Image + control instances with absolute `bounds` "x y w h").
- A control instance names a reusable definition (`mvKnob`, `mvSlider`, `mvToggle`) and binds with `"handle remapping": {"Data": "Parameter N"}` where N is the VST2 parameter index.
- Definitions: `Knob` (FilmStrip PNG, 127 frames, vertical drag), `Button` (on/off PNG), `Label` (Name/Value text from the plugin), `Focus` frame; actions `Q-Link`, `Show Overlay` ("knob overlay" from `/usr/share/Akai/Content/Synths/Generic/`), `Toggle Switch`.
- `Q-Links.json`: per-tab `Screen Mode Q-Links` map and a flat `Program Mode Q-Links`.

## This skin (MV-8000 front-panel layout, 1280x628)
Modelled on `skin/mpcmv8000_reference.png`: dark header with tab chips, brushed-silver chassis, blue LCD, black knobs, segmented switches, 4x4 pad grid, 16 pad-volume faders.
**Tab 1 "Pad"** (everything on one screen):
- MODE segment switch (Drum kit / Synth, param 29) and PAD selector knob.
- QUICK EDIT: Cutoff, Reson, Attack, Release (Q-Links 1-4).
- LCD "PAD PARAMETERS": live read-outs of Pad, Mode, Gate, Master, Cutoff, Reson, Level (the text comes from the plugin's parameter name/display strings).
- MASTER knob; PAD PARAMETERS panel: Level, Pan, Coarse, Fine, Attack, Decay, Sustain, Release, Cutoff, Reson knobs and a One-shot/Gate switch.
- PAD VOLUME: 16 faders (2 rows of 8). The 4x4 pad grid is artwork showing the MPC hardware pad layout (pad 1 bottom-left); it is not clickable.
**Tab 2 "Mixer"**: 16 large faders with name and dB value.
Q-Links: 1-4 Cutoff/Reson/Attack/Release, 5-8 Level/Pan/Coarse/Fine, 9-12 Decay/Sustain/Pad/Gate, 13 Master, 14 Mode; Mixer tab Q-Link n = pad n.
**Disabled/artwork only** (the plugin has nothing behind them): BROWSE / EFFECTS / SYSTEM tab chips (dimmed). The MV-8000's patch browser, waveform editor, MFX/chorus/reverb and pad banks are not reproduced.
`python3 tools/preview_skin.py out.png` composites a preview from the generated sprites (not an on-device render).
`tests/test_skin.py` checks indices, bounds, sprite sizes and Q-Link targets (LCD read-outs and quick-edit knobs intentionally mirror another control, so they are exempt from the duplicate-binding check).

## Not verified (needs a device or more files)
0. **New sprites** (small knob 40px, small fader 28x80, segmented switches 104x76 / 150x40) follow the same assumptions as below; whether the MPC scales or clips Button/FilmStrip images that match their bounds is unverified.
1. **Film-strip orientation/frame size.** Sprites are vertical strips (58x7366 knob, 34x12573 slider) because bounds equal one frame. The JV-880 PNGs were not provided to confirm.
2. **`version.xml`**: format now known from the JV-880 file (`<plugincontent version="1.0"><identifier>sd88me.vst.jv-880</identifier><version>1.0.0.0</version>`). Ours is generated as `mvlib.vst.mpcmv` / `0.3.2.0`.
3. **Folder name / install path: now confirmed from the JV-880 package** (`plugin.xml`: name="JV-880", manufacturer="sd88me"; `install.sh`: skin folder `sd88me - VST - JV-880` copied to `/sdcard/Synths/`; plugin in `/sdcard/vst/`; settings `/media/az01-internal/Settings/*/MPC.settings`; `/sdcard/Synths` must be in MPC's SynthContentLocations). Ours: manufacturer `mvlib`, name `MV-8000`, folder `mvlib - VST - MPCMV`. The `plugin.xml` uid is lowercase hex of the VST uniqueID, as in the JV-880 file. Still unconfirmed: that the MPC accepts a skin with a plugin whose vendor/name strings match this way on *our* binary (not run on a device).
4. Font "Titillium Web" and the overlay import paths are assumed present on the MPC (the JV-880 skin uses them).
5. Nothing here has run on an MPC. The ARM plugin binary is still only built by CI.
