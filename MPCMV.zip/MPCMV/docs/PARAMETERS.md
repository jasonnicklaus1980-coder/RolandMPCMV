# Plugin parameters (VST2, 29)

Index | Name (`effGetParamName`) | Meaning | Default
--- | --- | --- | ---
0 | Master | master gain | 0.8 (0 dB)
1 | Pad | which pad the pad_* parameters edit (pads 1-16) | pad 1
2 | Level | selected pad level | 0.8 (0 dB)
3 | Pan | constant-power pan | center
4 | Coarse | +/-24 semitones | 0
5 | Fine | +/-50 cents | 0
6 | Attack | 0 to ~10 s (exponential taper) | 0
7 | Decay | time to fall to sustain | 0.5
8 | Sustain | 0-127 display | 127 (full)
9 | Release | release time after note-off (gate mode) | 0.5
10 | Gate | One-shot (ignore note-off) / Gate (note-off starts release) | One-shot
11 | Cutoff | global 12 dB/oct low-pass, 20 Hz-20 kHz, bypassed when fully open | open
12 | Reson | global filter resonance | 0
13-28 | Pad 1 ... Pad 16 | direct per-pad level (same storage as pad_level) | 0.8

Display strings come from `effGetParamDisplay`, units from `effGetParamLabel`, and `effCanBeAutomated` returns 1.
With default values, output is unchanged from the pre-parameter build (pad 1 energy 2044.619).

## Binding (confirmed from the JV-880 skin files)
MPC skins bind by VST2 parameter **index**: `TUI.json` uses `"Data": "Parameter N"` and `Q-Links.json` maps Q-Link 1-16 to indices (-1 = unused). Index order above is therefore part of the skin contract: do not reorder without regenerating the skin (`python3 tools/build_skin.py`). Name/Value labels in the skin show `effGetParamName` / `effGetParamDisplay`, so names are short and readable.
Tested on x86 with `make test-params` (level, pan, coarse pitch, attack, filter, gate/release, names). Not tested on an MPC.

## What `jv880.so` showed (inspected, not run)
- 32-bit ARM, EABI5, hard-float (flags 0x5000400); needs libstdc++, libm, libgcc_s, libc; exports `VSTPluginMain` and `move_plugin_init_v2` (a second, non-VST entry point). Matches this project's armv7 hard-float target.
- Reads ROMs from `/sdcard/vst/jv880-roms`, consistent with `/sdcard/vst/` as the plugin directory.
- Embeds `chain_params` (list of `{key,name,type,min,max,options}`) and `ui_hierarchy` JSON (levels, 8 `knobs` keys with `knob_labels`, parameter `key`/`label`/`short_name`). These look like the plugin's own metadata for another host's UI; whether the MPC `Q-Links.json`/`TUI.json` use the same schema is unknown. The `.so` contains no reference to `Plugin Skins`, `TUI` or `Q-Links`, so the skin files are read by the host, not the plugin.


## Added Drum/Synth mode (parameter 29)
- `Mode`: 0 = Drums (MIDI notes 36–51 trigger samples 1–16); 1 = Synth (any MIDI note selects the sample whose stored root key is closest and transposes from that root key). The mode is included in VST2 state chunks.
- VST programs select `.MV0` patches found recursively in `Samples/Patches/`; program names are derived from filenames. The plugin loads one patch at a time, allowing patches with more than 16 sample records.
- Sample root keys are read from the observed MVFF sample record field. This nearest-root-key approach is a basic playable approximation, not full decoding of Roland velocity layers, key zones, loops, filters, or envelopes.
