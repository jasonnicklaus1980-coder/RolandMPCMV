# Build status — Roland MV Library prototype

## Verified in this workspace (source 0.3.2)
- `make host-smoke` builds the x86-64 shared object, loads it through a small test host, opens the effect, sends MIDI note 36 (pad 1), processes stereo audio, and verifies non-zero output. Last observed result: `PASS`, output energy 1521.4055.
- `python3 tools/validate_samples.py` confirms 16 candidate WAVs are structurally readable as mono 16-bit PCM WAVs at the assumed 44.1 kHz.
- The source now linearly interpolates sample reads when the host sample rate differs from the file sample rate, stores samples as int16 PCM to reduce memory, and honors MIDI delta-frame offsets within each block.
- MVFF extraction remains experimental.

## Not verified / not complete
- The local shared object is x86-64 and is for host testing only. No ARM hard-float compiler/sysroot was available in this workspace, so the ARM binary has not been built locally. GitHub Actions is configured to cross-compile and check it.
- No MPC X / Hakai 3.8 device test has been performed.
- MVFF sample encoding interpretation (16-bit big-endian PCM, mono, 44.1 kHz) remains a hypothesis; no reference export has confirmed it.
- Native MV patch partial/key zones, exact velocity switching, original synthesis/effects, and drum kit pad-assignment PRM are not fully decoded. Full song/project loading and MC-909 support are out of scope for this Drum/Synth build.
- The PNG and layout JSON are a visual concept/specification, not a functional native MPC UI. There is no custom editor or Q-Link implementation in this prototype.
- VST2 ABI and MIDI handling have only been smoke-tested with the included minimal host, not with MPC OS.

## Build for target
GitHub Actions installs `g++-arm-linux-gnueabihf`, builds `payload/vst/mpcmv.so`, checks that it is 32-bit ARM, and packages the test artifact. Do not install until the ARM artifact is reviewed and then tested on a backed-up MPC.

## Update: real MV0 decoded
- Real `MA_Dirt&GrimeKit.MV0` parsed: chunked container, 16-bit BE PCM, **12 stereo + 4 mono samples** (earlier mono-only decode was wrong for pads 1-12; fixed in decoder, C++ loader, and shipped WAVs).
- `make test-decode`: synthetic fixture PASS; with `MV_REAL_KIT` set, real kit PASS; with `MV_FACTORY_ZIP` set, 96 factory patches / 1,571 samples parse.
- Plugin loading the real `.MV0` directly as `kit.MV0` produces output identical to the decoded-WAV path (energy 2044.6194 on pad 1).
- `make host-smoke`, `make host-smoke-mvff`, `make validate` PASS.

## Still not verified
- Sample rate (assumed 44.1 kHz). No MV-8000/8800 project, pattern, or sequence files have been seen; only this one drum-kit patch. Other MV patch types (instruments, effects) and the kit PRM parameter block are undecoded.
- ARM binary not built locally (no cross compiler); CI builds it. No MPC/Hakai device test.

## Update: MV-8000 factory patches (96 of 103 readable)
- The uploaded factory-patch zip is corrupt (re-upload is byte-identical): 7 `.MV0` files cannot be extracted (RawStereoDRM, Killer Conga, MV RealClaps, 4 Rhodes/EP patches).
- All 96 readable patches share the same container (`MVFF`, `0x75`, `PAT `, `FMT `, kit `PRM`, `SMPL`) and all samples are 16-bit BE mono. Earlier claim "end index = frames-1/-2" was specific to one kit and is retracted; end index is a trim point.
- **Not supported:** the plugin only plays `Samples/kit.MV0` as 16 pads. Instrument/multisample patches (up to dozens of samples per patch) need the kit/patch `PRM` block decoded (key ranges, velocity layers, loops, envelopes), which has not been done. Sample rate is still assumed 44.1 kHz.
- No native MPC skin: the skin format is still unknown (see skin/README.md). The SP1200 `SHA256SUMS` file lists only checksums of a package that was not supplied.

## Update: named parameters + DSP (see docs/PARAMETERS.md)
- 29 VST2 parameters with names/display/automation, per-pad level/pan/pitch/envelope, global filter, gate mode; `make test-params` PASS on x86 (host-side only).
- `jv880.so` inspected (ARM hard-float VST2, plus a second entry point); no skin schema inside it. Native MPC skin still blocked on `TUI.json` / `Q-Links.json` / `version.xml`.

## Update: generated MPC skin (docs/SKIN.md)
- Skin schema recovered from the JV-880 `TUI.json` / `Q-Links.json`: bindings are by VST2 parameter index. Parameter names were changed to short readable labels (skin Name labels display them); indices unchanged.
- `tools/build_skin.py` generates TUI.json, Q-Links.json and sprites; `make test-skin` validates it and (given the JV-880 files) checks JSON shape equality. Unverified: film-strip orientation, version.xml, folder naming/install path, on-device rendering.

## Update: installer rewritten after the JV-880 package
- Reference files received: `plugin.xml`, `install.sh`, `uninstall.sh`, `plugin_list.awk` (identical to ours), `INSTALL.md`, `version.xml`. They confirm: folder `<manufacturer> - VST - <name>`, `/sdcard/Synths` + `/sdcard/vst`, `pluginList-arm` editing, Gen1 32-bit ARM devices only.
- Our installer previously did not wait for MPC to exit before editing `MPC.settings` and did not verify files; both added (as in JV-880). Samples you add are preserved on upgrade/uninstall.
- `make test-install` runs install/upgrade/uninstall against a fake filesystem with 3 settings shapes (existing list, empty `<KNOWNPLUGINS/>`, no list): placement, exactly-one-entry, valid XML, backup, stop/start, user-sample safety, refusals (non-ARM, checksum mismatch). Passing here does not prove behaviour on a device.
- `tools/make_release.sh` builds the release folder + SHA256SUMS; CI uses it for the ARM package.

## Update: fixes from review (source 0.3.3-pre)
- **MIDI input fixed.** The VST2 `VstMidiEvent` has `noteLength`/`noteOffset` before `midiData`, so the status/note/velocity bytes are at struct offset 24, not 16. The plugin and every test used a wrong layout (bytes at offset 16), so tests passed while a real host's notes would have been ignored. The plugin now uses the real layout (with a `static_assert`) and all tests build events the same way.
- Added `effGetPlugCategory` (synth) and MIDI CC 120/123 (all sound/notes off).
- ARM link now uses `-static-libstdc++ -static-libgcc`; CI builds on ubuntu-22.04 and fails if libstdc++ is still dynamic, and prints the highest glibc symbol version needed. The device's glibc version is unknown, so this lowers but does not remove load risk.
- Still unverified: ARM build (no cross compiler locally), anything on a real MPC.
- Known limitation: plugin state is global (single instance); two instances on separate tracks share settings.
- Skin redone as an MV-8000 front-panel layout (see docs/SKIN.md); generator no longer fails if the DejaVu font path is missing; `tools/preview_skin.py` renders a preview (not an on-device render).
