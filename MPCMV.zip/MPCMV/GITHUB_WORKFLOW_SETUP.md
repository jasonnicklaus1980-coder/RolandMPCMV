# Uploading this project to GitHub and running the build workflow

## Upload from Android

1. In GitHub, create a repository named `mpcmv` (README can be omitted).
2. Download and extract this ZIP on a computer if possible. **Upload the contents of the `MPCMV/` folder**, not the outer folder and not the ZIP itself. Keep hidden paths such as `.github/workflows/build.yml`.
3. On the repository page choose **Add file → Upload files**, select the extracted files/folders, then commit to `main`.
4. Open **Actions**. The workflow **Build and validate Roland MV MPC plugin** runs automatically after the push. You can also select it and choose **Run workflow**.
5. Open the completed run. Under **Artifacts**, download `mpcmv-armv7-hakai-test-build`. This is a test package; it is not confirmed on real MPC X hardware.

## What the workflow does

- Builds and tests the desktop host smoke-test plugin.
- Runs parameter, state, synth-mode, MIDI-timing, decoder, patch-staging, skin, installer, and WAV-validation checks.
- Cross-compiles a 32-bit ARMv7 hard-float VST2 shared object with Ubuntu's ARM toolchain.
- Checks ELF architecture and exported VST2 entry points.
- Packages and uploads the ARM test build as a GitHub Actions artifact.

## Important limitations

A successful GitHub build verifies compilation and the automated checks only. It does not verify plugin registration, sound output, GUI rendering, or installation on the MPC X/Hakai 3.8. Back up the device before testing; do not treat the CI artifact as a verified production release. The MV patch reader is experimental and does not yet reproduce every original Roland synth parameter, multisample zone, or effect.
